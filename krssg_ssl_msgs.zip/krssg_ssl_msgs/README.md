# krssg_ssl_msgs
Package to contain messages for SSL 


Add this to all packages built for SSL and add all ROS messages to this package.
